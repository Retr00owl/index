import java.time.LocalDate;
import java.util.Arrays;


public class InventoryManager {
private Product[] products;
private final int capacity;


public InventoryManager(int capacity) {
this.capacity = capacity;
products = new Product[capacity];
}


public void addProduct(Product p) throws InventoryFullException {
for (int i = 0; i < capacity; i++) {
if (products[i] == null) {
products[i] = p;
return;
}
}
throw new InventoryFullException("Inventory is full. Cannot add more products.");
}


public Product searchProduct(int productId) throws ProductNotFoundException {
for (Product p : products) {
if (p != null && p.getProductId() == productId) return p;
}
throw new ProductNotFoundException("Product with ID " + productId + " not found.");
}


public void viewProducts() {
boolean found = false;
for (Product p : products) {
if (p != null) {
p.displayProductInfo();
found = true;
}
}
if (!found) System.out.println("No products in inventory.");
}


public void updateProduct(int productId, Double newPrice, Integer newQty) throws ProductNotFoundException {
Product p = searchProduct(productId);
if (newPrice != null) p.setPrice(newPrice);
if (newQty != null) p.setQuantity(newQty);
}


public void deleteProduct(int productId) throws ProductNotFoundException {
for (int i = 0; i < capacity; i++) {
if (products[i] != null && products[i].getProductId() == productId) {
products[i] = null; // removed
return;
}
}
throw new ProductNotFoundException("Product with ID " + productId + " not found to delete.");
}


// Helpful for testing / export
public Product[] getProductsArray() {
return Arrays.copyOf(products, products.length);
}
}