import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PerishableProduct extends Product {

    private LocalDate expiry;

    public PerishableProduct(int id, String name, double price, int qty, LocalDate expiry) {
        super(id, name, price, qty);
        this.expiry = expiry;
    }

    public LocalDate getExpiry() {
        return expiry;
    }

    public void setExpiry(LocalDate expiry) {
        this.expiry = expiry;
    }

    @Override
    public void displayProductInfo() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        System.out.printf("ID: %d | Name: %s | Price: %.2f | Qty: %d | Expiry: %s\n",
                getProductId(), getName(), getPrice(), getQuantity(), expiry.format(fmt));
    }
    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return "ID: " + getProductId() +
               ", Name: " + getName() +
               ", Price: " + getPrice() +
               ", Qty: " + getQuantity() +
               ", Expiry: " + expiry.format(fmt);
    }
}