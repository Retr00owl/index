import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class MainApp extends JFrame {

    InventoryManager manager = new InventoryManager(100);

    public MainApp() {
        setTitle("Inventory System");
        setSize(600, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Add", addPanel());
        tabs.add("View", viewPanel());
        tabs.add("Search", searchPanel());
        tabs.add("Update", updatePanel());
        tabs.add("Delete", deletePanel());
        add(tabs);
    }

    private JPanel addPanel() {
        JPanel p = new JPanel(new GridLayout(7, 2));
        JTextField id = new JTextField(), name = new JTextField(), price = new JTextField(), qty = new JTextField(), exp = new JTextField("yyyy-MM-dd");
        JCheckBox per = new JCheckBox("Perishable");
        exp.setEnabled(false);
        per.addActionListener(e -> exp.setEnabled(per.isSelected()));
        JButton add = new JButton("Add");

        add.addActionListener(e -> {
            try {
                int i = Integer.parseInt(id.getText());
                double pr = Double.parseDouble(price.getText());
                int q = Integer.parseInt(qty.getText());
                if (per.isSelected()) {
                    manager.addProduct(new PerishableProduct(i, name.getText(), pr, q, LocalDate.parse(exp.getText())));
                } else {
                    manager.addProduct(new Product(i, name.getText(), pr, q));
                }
                JOptionPane.showMessageDialog(this, "Added!");
                id.setText(""); name.setText(""); price.setText(""); qty.setText(""); exp.setText("yyyy-MM-dd");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, ex.getMessage()); }
        });

        p.add(new JLabel("ID")); p.add(id);
        p.add(new JLabel("Name")); p.add(name);
        p.add(new JLabel("Price")); p.add(price);
        p.add(new JLabel("Qty")); p.add(qty);
        p.add(per); p.add(exp);
        p.add(new JLabel("")); p.add(add);
        return p;
    }

    private JPanel viewPanel() {
        JPanel p = new JPanel(new BorderLayout());
        JTextArea area = new JTextArea();
        JButton ref = new JButton("Refresh");
        ref.addActionListener(e -> {
            area.setText("");
            for (Product x : manager.getProductsArray())
                if (x != null) area.append(x.toString() + "\n");
        });
        p.add(ref, BorderLayout.NORTH);
        p.add(new JScrollPane(area), BorderLayout.CENTER);
        return p;
    }

    private JPanel searchPanel() {
        JPanel p = new JPanel(new GridLayout(3, 2));
        JTextField id = new JTextField();
        JTextArea res = new JTextArea(); res.setEditable(false);
        JButton s = new JButton("Search");
        s.addActionListener(e -> {
            try { res.setText(manager.searchProduct(Integer.parseInt(id.getText())).toString()); }
            catch (Exception ex) { res.setText(ex.getMessage()); }
        });
        p.add(new JLabel("ID")); p.add(id);
        p.add(s); p.add(new JLabel(""));
        p.add(new JScrollPane(res));
        return p;
    }

    private JPanel updatePanel() {
        JPanel p = new JPanel(new GridLayout(4, 2));
        JTextField id = new JTextField(), price = new JTextField(), qty = new JTextField();
        JButton u = new JButton("Update");

        u.addActionListener(e -> {
            try {
                Integer q = qty.getText().isEmpty() ? null : Integer.parseInt(qty.getText());
                Double pr = price.getText().isEmpty() ? null : Double.parseDouble(price.getText());
                manager.updateProduct(Integer.parseInt(id.getText()), pr, q);
                JOptionPane.showMessageDialog(this, "Updated!");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, ex.getMessage()); }
        });

        p.add(new JLabel("ID")); p.add(id);
        p.add(new JLabel("New Price")); p.add(price);
        p.add(new JLabel("New Qty")); p.add(qty);
        p.add(new JLabel("")); p.add(u);
        return p;
    }

    private JPanel deletePanel() {
        JPanel p = new JPanel(new GridLayout(2, 2));
        JTextField id = new JTextField();
        JButton d = new JButton("Delete");
        d.addActionListener(e -> {
            try { manager.deleteProduct(Integer.parseInt(id.getText())); JOptionPane.showMessageDialog(this, "Deleted!"); }
            catch (Exception ex) { JOptionPane.showMessageDialog(this, ex.getMessage()); }
        });
        p.add(new JLabel("ID")); p.add(id);
        p.add(d);
        return p;
    }

    public static void main(String[] args) {
        new MainApp().setVisible(true);
    }
}